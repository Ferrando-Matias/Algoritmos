﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_con_Listas
{
    public static class LstaPersonas
    {
        public static List<Persona> lPersonas = new List<Persona>();


   
    }
}
