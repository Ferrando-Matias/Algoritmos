﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_56
{
    internal class totales
    {
        public string Nombre { get; set; }
        public double Monto { get; set; }
    }
}
