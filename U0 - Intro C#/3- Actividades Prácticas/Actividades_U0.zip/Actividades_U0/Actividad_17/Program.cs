﻿/* Enunciado:
             * 17)	Muestra los números del 1 al 100
             */
for (int i = 1; i < 101; i++)
{
    Console.WriteLine(i);
}
Console.ReadKey();