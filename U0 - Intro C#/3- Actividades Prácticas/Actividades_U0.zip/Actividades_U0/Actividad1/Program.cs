﻿/*ENUNCIADO:
             * 1)	Crear 3 variables numéricas con el valor que deseen y en otra variable numérica
             * guardar el valor de la suma de las 3 anteriores. Mostrar por consola. 
             */
int numeroUno = 5;
int numeroDos = 6;
int numeroTres = 4;
int resultado = numeroUno + numeroDos + numeroTres;
Console.WriteLine("La suma de los numeros {0}, {1} y {2} es: {3}", numeroUno, numeroDos, numeroTres, resultado);
Console.ReadKey();